function getProducts() {
    fetch('https://diwserver.vps.webdock.cloud/products')
      .then(response => response.json())
      .then(data => displayProductList(data))
      .catch(error => {
        console.error('Ocorreu um erro ao obter os produtos:', error);
      });
  }
  
  function displayProductList(products) {
    const produtosContainer = document.querySelector('.produtos');
  
    products.forEach(product => {
      const card = document.createElement('div');
      card.classList.add('positioncard');
  
      const cardContent = `
        <div class="card">
          <div class="imgbx">
            <img src="${product.image}" width="250px" height="250px" />
          </div>
          <div class="contentbx">
            <h3>${product.name}</h3>
            <h2 class="preço">R$${product.price.toFixed(2)}<small>${product.decimal}</small></h2>
            <button>comprar</button>
          </div>
        </div>
      `;
  
      card.innerHTML = cardContent;
      produtosContainer.appendChild(card);
    });
  }
  
  
  getProducts();
  var searchButton = document.getElementById('search-button');

function handleClick() {
  searchButton.classList.add('clicked');
  setTimeout(function() {
    searchButton.classList.remove('clicked');
  }, 200);
}

searchButton.addEventListener('click', handleClick);

  